// function to check whether it is a valid state
const hasTwoCharacters = (str: string): boolean => {
  return str.length === 2;
};

export default hasTwoCharacters;
